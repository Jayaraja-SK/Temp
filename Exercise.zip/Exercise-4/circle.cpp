#include<glut/glut.h>
#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;

void myInit() {

    glClearColor(1.0,1.0,1.0,0.0);
    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(10);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10.0,10.0,-10.0,10.0);

}


void plotPointString(int x, int y, int pos)
{
    glRasterPos2f(x,y+pos);

    std::string string;

    string="("+std::to_string(int(round(x)))+","+std::to_string(int(round(y)))+")";

    char *s=const_cast<char*>(string.c_str());

    for (char* c = s; *c != '\0'; c++)
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10 , *c);
}


void plotPoint(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2f(x,y);
    glEnd();
}

void Bresenham_Circle()

{
    glClear(GL_COLOR_BUFFER_BIT);

    glRasterPos2f(0.0f,0.0f);

    glLineWidth(2);
    glPointSize(7);
    glBegin(GL_LINES);
    
    glVertex3f(-320.0f,0.0f,0.0f);
    glVertex3f(320.0f,0.0f,0.0f);

    glEnd();

    
    glLineWidth(2);

    glBegin(GL_LINES);

    glVertex3f(0.0f,-240.0f,0.0f);
    glVertex3f(0.0f,240.0f,0.0f);

    glEnd();
    
    
    glLineWidth(2);
    glBegin(GL_LINES);
    glVertex3f(0,0,0.0f);
    glVertex3f(50,50,0.0f);
    glEnd();
    
    float xc,yc,r;

    cout << "xc = ";
    cin >> xc;
    cout << "yc = ";
    cin >> yc;
    cout << "r = ";
    cin >> r;

    plotPoint(xc,yc);
    plotPointString(xc, yc, 0);
    
    int x=0,y=r;
    
    int p=1-r;
    
    while(x<=y)
    {
        plotPoint(x+xc,y+yc); // QUAD-1
        plotPointString(x+xc, y+yc, 0);
        
        plotPoint(y+xc,x+yc);
        plotPointString(y+xc, x+yc, 0);
        
        plotPoint(-x+xc,y+yc); // QUAD-2
        plotPointString(-x+xc, y+yc, 0);
        
        plotPoint(-y+xc,x+yc);
        plotPointString(-y+xc, x+yc, 0);
        
        plotPoint(-y+xc,-x+yc); // QUAD-3
        plotPointString(-y+xc, -x+yc, 0);
        
        plotPoint(-x+xc,-y+yc);
        plotPointString(-x+xc, -y+yc, 0);
        
        plotPoint(x+xc,-y+yc); //QUAD-4
        plotPointString(x+xc, -y+yc, 0);
        
        plotPoint(y+xc,-x+yc);
        plotPointString(y+xc, -x+yc, 0);
        
        x=x+1;
        
        if(p>0)
        {
            y=y-1;
            
            p=p+2*x-2*y+1;
        }
        else
        {
            p=p+2*x+1;
        }
        
    }
  
    glEnd();
    glFlush();
}


int main(int argc,char* argv[])

{

    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowSize(640,480);
    glutCreateWindow("Fourth Exercise");
    glutDisplayFunc(Bresenham_Circle);
    myInit();
    glutMainLoop();

    return 1;

}
