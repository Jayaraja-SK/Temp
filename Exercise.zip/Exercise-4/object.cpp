#include<GL/glut.h>
#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;

void myInit() {

    glClearColor(1.0,1.0,1.0,0.0);
    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(4);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10.0,10.0,-10.0,10.0);
}



void plotPointString(int x, int y, int pos)
{
    glRasterPos2f(x,y+pos);
  
    std::string string;

    string="("+std::to_string(int(round(x)))+","+std::to_string(int(round(y)))+")";

    char *s=const_cast<char*>(string.c_str());

    for (char* c = s; *c != '\0'; c++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10 , *c);
}



void plotPoint(float x, float y)
{
    glBegin(GL_POINTS);
    glVertex3f(x,y,0.0f);
    glEnd();
}



void drawCircle(float r, float xc, float yc)
{
    float angle,x,y;

    for(angle=0;angle<=(2*3.14);angle+=0.01)
    { 
        x=r*sin(angle);
        y=r*cos(angle);

        plotPoint(x+xc,y+yc);
    }

    glEnd();
}



void Object()

{
    glClear(GL_COLOR_BUFFER_BIT);
    
    drawCircle(2,0,2); // FACE

    drawCircle(0.5,-1,4.5); // EAR

    drawCircle(0.5,1,4.5); // EAR


    glLineWidth(5); // BODY
    glBegin(GL_LINES);
    glVertex3f(0,0,0.0f);
    glVertex3f(0,-5,0.0f);
    glEnd();


    glLineWidth(5); // HAND
    glBegin(GL_LINES);
    glVertex3f(0,-2.5,0.0f);
    glVertex3f(2,-0.5,0.0f);
    glEnd();


    glLineWidth(5); // HAND
    glBegin(GL_LINES);
    glVertex3f(0,-2.5,0.0f);
    glVertex3f(-2,-0.5,0.0f);
    glEnd();


    glLineWidth(5); // LEG
    glBegin(GL_LINES);
    glVertex3f(0,-5,0.0f);
    glVertex3f(2,-7.5,0.0f);
    glEnd();


    glLineWidth(5); // LEG
    glBegin(GL_LINES);
    glVertex3f(0,-5,0.0f);
    glVertex3f(-2,-7.5,0.0f);
    glEnd();
    
    glEnd();
    glFlush();

}


int main(int argc,char* argv[])

{

    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowSize(640,480);
    glutCreateWindow("Fourth Exercise");
    glutDisplayFunc(Object);
    myInit();
    glutMainLoop();

    return 1;

}
