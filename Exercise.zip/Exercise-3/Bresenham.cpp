#include <GL/glut.h>
#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;


void myInit() {
    glClearColor(1.0,1.0,1.0,0.0);
    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(10);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10.0,10.0,-10.0,10.0);
}


void plotPointString(int x, int y, int pos){    
    glRasterPos2f(x,y+pos);  
    std::string string;
    
    string="("+std::to_string(int(round(x)))+","+std::to_string(int(round(y)))+")";
    
    char *s=const_cast<char*>(string.c_str());
    
    for (char* c = s; *c != '\0'; c++)
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10 , *c);}


void plotPoint(int x, int y)
{    
    glBegin(GL_POINTS);
    glVertex2f(x,y);
    glEnd();
}




void Bresenham()
{
    
    glClear(GL_COLOR_BUFFER_BIT);

    glRasterPos2f(0.0f,0.0f);
    plotPointString(0,0,0);

    glLineWidth(2);    
    glPointSize(7);    

    glBegin(GL_LINES);        
    glVertex3f(-320.0f,0.0f,0.0f);    
    glVertex3f(320.0f,0.0f,0.0f);
    glEnd();
    
    glLineWidth(2);
    glBegin(GL_LINES);
    glVertex3f(0.0f,-240.0f,0.0f);    
    glVertex3f(0.0f,240.0f,0.0f);
    glEnd();

    float xa,ya,xb,yb;

    cout << "xa = ";
    cin >> xa;    
    cout << "ya = ";    
    cin >> ya;    
    cout << "xb = ";    
    cin >> xb;    
    cout << "yb = ";    
    cin >> yb;
    
    glLineWidth(2);    
    glBegin(GL_LINES);    
    glVertex3f(xa,ya,0.0f);    
    glVertex3f(xb,yb,0.0f);    
    glEnd();


    glBegin(GL_POINTS);        

    int dx,dy;        

    dy=abs(yb-ya);    
    dx=abs(xb-xa);        

    int m,p,flag,limit;        

    m=dy/dx;        

    if(m<1)    
    {        
        flag=0;    
        limit=dx;
    }    
    else    
    {        
        flag=1;   
        limit=dy; 
    }      

    if(flag==0)    
    {        
        p=2*dy-dx;    
    }    
    else    
    {        
        p=2*dx-dy;    
    }        

    int x=xa,y=ya;        


    plotPoint(x,y);  
    plotPointString(x,y,0);  

    int i;    

    for(i=0;i<limit;i++) 
    {        
        if(flag==0)        
        {            
            x=x+(dx/(xb-xa));        
        }        
        else        
        {            
            y=y+(dy/(yb-ya));        
        }                

        if(p<0)        
        {            
            if(flag==0)            
            {                
                p=p+2*dy;            
            }            
            else           
            {                
                p=p+2*dx;            
            }        
        }        
        else        
        {            
            if(flag==0)            
            {      
                p=p+2*(dy-dx);           
                y=y+(dy/(yb-ya));            
            }            
            else            
            {            
                p=p+2*(dx-dy);       
                x=x+(dx/(xb-xa));              
            }        
        }                
              

        plotPoint(x,y);
        plotPointString(x,y,0);  
    }        

    glEnd();
    glFlush();
}






int main(int argc,char* argv[])
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowSize(640,480);
    glutCreateWindow("Third Exercise");
    glutDisplayFunc(Bresenham);
    myInit();
    glutMainLoop();
    return 1;
}