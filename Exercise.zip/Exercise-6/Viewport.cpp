#include <GL/glut.h>
#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;


void myInit() {
    glClearColor(1.0,1.0,1.0,0.0);
    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(10);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10.0,10.0,-10.0,10.0);
}


void plotPointString(int x, int y, int pos)
{
    glRasterPos2f(x,y+pos);

    std::string string;
    
    string="("+std::to_string(int(round(x)))+","+std::to_string(int(round(y)))+")";

    char *s=const_cast<char*>(string.c_str());

    for (char* c = s; *c != '\0'; c++)
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10 , *c);
}



void plotPoint(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2f(x,y);
    glEnd();
}



float getXMin(float points[4][2])
{
    int i;

    float min_val = points[0][0];

    for(i=1;i<4;i++)
    {
        if(min_val>points[i][0])
        {
            min_val = points[i][0];
        }
    }

    return min_val;
}


float getYMin(float points[4][2])
{
    int i;

    float min_val = points[0][1];

    for(i=1;i<4;i++)
    {
        if(min_val>points[i][1])
        {
            min_val = points[i][1];
        }
    }

    return min_val;
}


float getXMax(float points[4][2])
{
    int i;

    float max_val = points[0][0];

    for(i=1;i<4;i++)
    {
        if(max_val<points[i][0])
        {
            max_val = points[i][0];
        }
    }

    return max_val;
}


float getYMax(float points[4][2])
{
    int i;

    float max_val = points[0][1];

    for(i=1;i<4;i++)
    {
        if(max_val<points[i][1])
        {
            max_val = points[i][1];
        }
    }

    return max_val;
}


void Square(float xa, float ya, float xb, float yb)
{
    glBegin(GL_QUADS);
    glVertex3f(xa,ya,0.0f);
    glVertex3f(xb,ya,0.0f);
    glVertex3f(xb,yb,0.0f);
    glVertex3f(xa,yb,0.0f);
    glEnd();
    glFlush();
}


float getX(float xw, float xvmin, float xwmin, float sx)
{
    float xv;

    xv = xvmin + (xw-xwmin)*sx;

    return xv;
}


float getY(float yw, float yvmin, float ywmin, float sy)
{
    float yv;

    yv = yvmin + (yw-ywmin)*sy;

    return yv;
}


void SquareViewPort(float xa, float ya, float xb, float yb, float window[4][2], float viewport[4][2])
{
    float xwmin, xwmax, ywmin, ywmax;

    xwmin = getXMin(window);
    ywmin = getYMin(window);
    xwmax = getXMax(window);
    ywmax = getYMax(window);


    float xvmin, xvmax, yvmin, yvmax;

    xvmin = getXMin(viewport);
    yvmin = getYMin(viewport);
    xvmax = getXMax(viewport);
    yvmax = getYMax(viewport);


    float sx, sy;

    sx = (xvmax-xvmin)/(xwmax-xwmin);
    sy = (yvmax-yvmin)/(ywmax-ywmin);



    glBegin(GL_QUADS);
    glVertex3f(getX(xa, xvmin, xwmin, sx),getY(ya, yvmin, ywmin, sy),0.0f);
    glVertex3f(getX(xb, xvmin, xwmin, sx),getY(ya, yvmin, ywmin, sy),0.0f);
    glVertex3f(getX(xb, xvmin, xwmin, sx),getY(yb, yvmin, ywmin, sy),0.0f);
    glVertex3f(getX(xa, xvmin, xwmin, sx),getY(yb, yvmin, ywmin, sy),0.0f);
    glEnd();
    glFlush();
}



void Region(float points[4][2])
{
    glLineWidth(2);

    glBegin(GL_LINES);

    glVertex3f(points[0][0],points[0][1],0.0f);
    glVertex3f(points[1][0],points[1][1],0.0f);

    glEnd();


    glLineWidth(2);

    glBegin(GL_LINES);

    glVertex3f(points[1][0],points[1][1],0.0f);
    glVertex3f(points[2][0],points[2][1],0.0f);

    glEnd();


    glLineWidth(2);

    glBegin(GL_LINES);

    glVertex3f(points[2][0],points[2][1],0.0f);
    glVertex3f(points[3][0],points[3][1],0.0f);

    glEnd();


    glLineWidth(2);

    glBegin(GL_LINES);

    glVertex3f(points[3][0],points[3][1],0.0f);
    glVertex3f(points[0][0],points[0][1],0.0f);

    glEnd();
}



void Viewport()
{
    glClear(GL_COLOR_BUFFER_BIT);
    
    glRasterPos2f(0.0f,0.0f);

    plotPointString(0,0,0);

    glLineWidth(2);
    glPointSize(7);
    glBegin(GL_LINES);
    
    glVertex3f(-320.0f,0.0f,0.0f);
    glVertex3f(320.0f,0.0f,0.0f);

    glEnd();

    

    glLineWidth(2);

    glBegin(GL_LINES);

    glVertex3f(0.0f,-240.0f,0.0f);
    glVertex3f(0.0f,240.0f,0.0f);

    glEnd();
    

    float window[4][2], viewport[4][2];

    cout << "ENTER CO-ORDINATES FOR WINDOW\n\n";

    cout << "POINT-1\n";

    cout << "x = ";
    cin >> window[0][0];
    cout << "y = ";
    cin >> window[0][1];

    cout << "\n";

    cout << "POINT-2\n";

    cout << "x = ";
    cin >> window[1][0];
    cout << "y = ";
    cin >> window[1][1];

    cout << "\n";

    cout << "POINT-3\n";

    cout << "x = ";
    cin >> window[2][0];
    cout << "y = ";
    cin >> window[2][1];

    cout << "\n";

    cout << "POINT-4\n";

    cout << "x = ";
    cin >> window[3][0];
    cout << "y = ";
    cin >> window[3][1];

    cout << "\n\n";


    glColor3f(1.0f,0.0f,0.0f);
    Region(window);



    cout << "ENTER CO-ORDINATES FOR VIEWPORT\n\n";

    cout << "POINT-1\n";

    cout << "x = ";
    cin >> viewport[0][0];
    cout << "y = ";
    cin >> viewport[0][1];

    cout << "\n";

    cout << "POINT-2\n";

    cout << "x = ";
    cin >> viewport[1][0];
    cout << "y = ";
    cin >> viewport[1][1];

    cout << "\n";

    cout << "POINT-3\n";

    cout << "x = ";
    cin >> viewport[2][0];
    cout << "y = ";
    cin >> viewport[2][1];

    cout << "\n";

    cout << "POINT-4\n";

    cout << "x = ";
    cin >> viewport[3][0];
    cout << "y = ";
    cin >> viewport[3][1];

    cout << "\n\n";


    glColor3f(0.0f,1.0f,0.0f);
    Region(viewport);


    float xa, ya, xb, yb;
    
    cout << "xa = ";
    cin >> xa;
    cout << "ya = ";
    cin >> ya;
    cout << "\n";
    
    cout << "xb = ";
    cin >> xb;
    cout << "yb = ";
    cin >> yb;
    
    cout << "\n";
    
    glColor3f(0.0f,0.0f,1.0f);
    Square(xa, ya, xb, yb);


    glColor3f(0.0f,0.0f,1.0f);
    SquareViewPort(xa, ya, xb, yb, window, viewport);


    glFlush();
}




int main(int argc,char* argv[])
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowSize(640,480);
    glutCreateWindow("Sixth Exercise");
    glutDisplayFunc(Viewport);
    myInit();
    glutMainLoop();
    return 1;
}
