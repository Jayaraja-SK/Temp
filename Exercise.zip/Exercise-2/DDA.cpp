#include<GL/glut.h>
#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;


void myInit() {

    glClearColor(1.0,1.0,1.0,0.0);
    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(10);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10.0,10.0,-10.0,10.0);

}


void plotPointString(int x, int y, int pos)
{
    glRasterPos2f(x,y+pos);

    std::string string;

    string="("+std::to_string(int(round(x)))+","+std::to_string(int(round(y)))+")";

    char *s=const_cast<char*>(string.c_str());

    for (char* c = s; *c != '\0'; c++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10 , *c);
}



void plotPoint(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2f(x,y);
    glEnd();
}





void DDA()

{
    glClear(GL_COLOR_BUFFER_BIT);

    glRasterPos2f(0.0f,0.0f);
    plotPointString(0,0,0);

    glLineWidth(2);
    glPointSize(7);


    glBegin(GL_LINES);
    glVertex3f(-320.0f,0.0f,0.0f);
    glVertex3f(320.0f,0.0f,0.0f);
    glEnd();


    glLineWidth(2);

    glBegin(GL_LINES);
    glVertex3f(0.0f,-240.0f,0.0f);
    glVertex3f(0.0f,240.0f,0.0f);
    glEnd();

    float xa,ya,xb,yb;

    cout << "xa = ";
    cin >> xa;
    cout << "ya = ";
    cin >> ya;
    cout << "xb = ";
    cin >> xb;
    cout << "yb = ";
    cin >> yb;

    

    glLineWidth(2);
    glBegin(GL_LINES);
    glVertex3f(xa,ya,0.0f);
    glVertex3f(xb,yb,0.0f);
    glEnd();

    float m=(yb-ya)/(xb-xa);

    float x, y;

    int choice;

    cout << "\n1. L->R\n";
    cout << "2. R->L\n";
    cout << "CHOICE = ";
    cin >> choice;


    if(m>0 && m<=1)

    {
        if(choice==1)

        {
            x=xa;
            y=ya;

            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xb) && y!=round(yb))

            {
                x=x+1;
                y=y+m;

                plotPointString(x,round(y),1);
                plotPoint(x,round(y));


            }

        }

        else if(choice==2)

        {

            x=xb;
            y=yb;

            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xa) && y!=round(ya))

            {
                x=x-1;
                y=y-m;

                plotPoint(x,round(y));
                plotPointString(x,round(y),1);
            }

        }

    }

    else if(m>1)

    {

        if(choice==1)

        {
            x=xa;
            y=ya;


            plotPoint(x,y);
            plotPointString(x,y,1);
            

            while(x!=round(xb) && y!=round(yb))

            {
                x=x+(1/m);
                y=y+1;

                plotPointString(round(x),y,1);
                plotPoint(round(x),y);

            }

        }

        else if(choice==2)

        {

            x=xb;
            y=yb;


            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xa) && y!=round(ya))

            {
                x=x-(1/m);
                y=y-1;

                plotPointString(round(x),y,1);
                plotPoint(round(x),y);
            }

        }

    }

    else if(m<0 && m>=-1)

    {

        if(choice==1)

        {

            x=xa;
            y=ya;

            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xb) && y!=round(yb))

            {
                x=x+1;
                y=y-abs(m);

                plotPointString(x,round(y),1);
                plotPoint(x,round(y));


            }

        }

        else if(choice==2)

        {

            x=xb;
            y=yb;

   
            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xa) && y!=round(ya))

            {
                x=x-1;
                y=y+abs(m);

                plotPointString(x,round(y),1);
                plotPoint(x,round(y));

            }

        }

    }

    else if(m<=-1)

    {

        if(choice==1)

        {

            x=xa;
            y=ya;

            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xb) && y!=round(yb))

            {
                x=x+abs((1/m));
                y=y-1;

                plotPointString(round(x),y,1);
                plotPoint(round(x),y);

            }

        }

        else if(choice==2)

        {
            x=xb;
            y=yb;

            plotPoint(x,y);
            plotPointString(x,y,1);

            while(x!=round(xa) && y!=round(ya))

            {
                x=x-abs((1/m));
                y=y+1;

                plotPointString(round(x),y,1);
                plotPoint(round(x),y);
            }

        }

    }

    glFlush();

}


int main(int argc,char* argv[])

{

    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowSize(640,480);
    glutCreateWindow("Second Exercise");
    glutDisplayFunc(DDA);
    myInit();
    glutMainLoop();

    return 1;

}