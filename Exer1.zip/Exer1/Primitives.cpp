#include<GL/glut.h>
#include <iostream>

using namespace std;


void myInit() {

    glClearColor(1.0,1.0,1.0,0.0);

    glColor3f(0.0f,0.0f,0.0f);

    glPointSize(10);

    glLineWidth(10);

    glMatrixMode(GL_PROJECTION);

    glLoadIdentity();

    gluOrtho2D(0.0,640.0,0.0,480.0);

}





void Points()

{

    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_POINTS);

    glVertex2d(150,100);

    glVertex2d(100,230);

    glVertex2d(170,130);

    glVertex2d(300,350);

    glEnd();

    glFlush();

}





void Lines()

{

    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_LINES);

    glVertex3f(100.0f,100.0f,0.0f);

    glVertex3f(200.0f,200.0f,0.0f);

    glEnd();

    glFlush();

}





void LineStrip()

{

    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_LINE_STRIP);

    glVertex3f(100.0f,100.0f,0.0f);

    glVertex3f(200.0f,200.0f,0.0f);

    glVertex3f(200.0f,300.0f,0.0f);

    glEnd();

    glFlush();

}



void Triangle()

{

    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_TRIANGLE_STRIP);

    glVertex3f(100.0f,100.0f,0.0f);

    glVertex3f(200.0f,200.0f,0.0f);

    glVertex3f(200.0f,300.0f,0.0f);

    glEnd();

    glFlush();

}





void Square()

{

    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_QUADS);

    glColor3f(240.0f,200.0f,0.0f);

    glVertex3f(0.0f,100.0f,0.0f);

    glVertex3f(100.0f,100.0f,0.0f);

    glVertex3f(100.0f,0.0f,0.0f);

    glVertex3f(0.0f,0.0f,0.0f);

    glEnd();

    glFlush();

}





int main(int argc,char* argv[])

{

    glutInit(&argc,argv);

    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);

    glutInitWindowSize(640,480);

    glutCreateWindow("First Exercise");

    int choice;

    cout << "1. POINTS\n";
    cout << "2. LINES\n";
    cout << "3. LINE STRIP\n";
    cout << "4. TRIANGLE\n";
    cout << "5. SQUARE\n\n";

    cout << "CHOICE = ";
    cin >> choice;

    if(choice==1)
    {
        glutDisplayFunc(Points);
    }
    else if(choice==2)
    {
        glutDisplayFunc(Lines);
    }
    else if(choice==3)
    {
        glutDisplayFunc(LineStrip);
    }
    else if(choice==4)
    {
        glutDisplayFunc(Triangle);
    }
    else if(choice==5)
    {
        glutDisplayFunc(Square);
    }

    myInit();

    glutMainLoop();

    return 1;

}


