#include<GL/glut.h>



void myInit() {

    glClearColor(1.0,1.0,1.0,0.0);

    glMatrixMode(GL_PROJECTION);

    glLoadIdentity();

    gluOrtho2D(0.0,640.0,0.0,480.0);

}





void Square_CB(float color, float xa, float ya, float xb, float yb)

{

    glBegin(GL_QUADS); // ON USING POLYGON, GL_END IS TO BE ADDED AFTER EACH SQUARE

    glColor3f(color, color, color);

    glVertex3f(xa,ya,0.0f);

    glVertex3f(xb,ya,0.0f);

    glVertex3f(xb,yb,0.0f);

    glVertex3f(xa,yb,0.0f);

    glEnd();

}







void House()

{

    glClear(GL_COLOR_BUFFER_BIT);



    glBegin(GL_QUADS);

    glColor3f(0.5f, 0.2f, 1.0f);

    glVertex3f(100,0,0.0f);

    glVertex3f(300,0,0.0f);

    glVertex3f(300,200,0.0f);

    glVertex3f(100,200,0.0f);

    glEnd();


    glBegin(GL_QUADS);

    glColor3f(1.0f, 0.2f, 0.3f);

    glVertex3f(150,0,0.0f);

    glVertex3f(250,0,0.0f);

    glVertex3f(250,150,0.0f);

    glVertex3f(150,150,0.0f);

    glEnd();


    glBegin(GL_TRIANGLE_STRIP);

    glColor3f(0.4f, 0.7f, 0.7f);

    glVertex3f(100,200,0.0f);

    glVertex3f(300,200,0.0f);

    glVertex3f(200,300,0.0f);

    glEnd();


    glBegin(GL_QUADS);

    glColor3f(0.2f, 1.0f, 0.1f);

    glVertex3f(300,0,0.0f);

    glVertex3f(600,0,0.0f);

    glVertex3f(600,200,0.0f);

    glVertex3f(300,200,0.0f);

    glEnd();


    glBegin(GL_QUADS);

    glColor3f(0.2f, 0.5f, 0.4f);

    glVertex3f(300,200,0.0f);

    glVertex3f(200,300,0.0f);

    glVertex3f(480,300,0.0f);

    glVertex3f(600,200,0.0f);

    glEnd();



    glBegin(GL_QUADS);

    glColor3f(1.0f, 1.0f, 1.0f);

    glVertex3f(400,60,0.0f);

    glVertex3f(500,60,0.0f);

    glVertex3f(500,140,0.0f);

    glVertex3f(400,140,0.0f);

    glEnd();


    glLineWidth(2);

    glBegin(GL_LINES);

    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex3f(450,60,0.0f);

    glVertex3f(450,140,0.0f);

    glEnd();

    glBegin(GL_LINES);

    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex3f(400,100,0.0f);

    glVertex3f(500,100,0.0f);

    glEnd();


    glFlush();

}







int main(int argc,char* argv[])

{

    glutInit(&argc,argv);

    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);

    glutInitWindowSize(640,480);

    glutCreateWindow("House");

    glutDisplayFunc(House);

    myInit();

    glutMainLoop();

    return 1;

}


